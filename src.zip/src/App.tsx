import { useState } from 'react';
import Selector from './components/Selector';
import RecommendationList from './components/RecommendationList';
import Papa from 'papaparse';

type Recommendations = {
  collaborative: string[];
  content: string[];
  azure: string[];
};

function App() {
  const [userId, setUserId] = useState('');
  const [recommendations, setRecommendations] = useState<Recommendations>({
    collaborative: [],
    content: [],
    azure: [],
  });

  const fetchCSVRecommendations = async (
    fileName: string,
    userId: string
  ): Promise<string[]> => {
    const response = await fetch(`/${fileName}`);
    const csvText = await response.text();

    return new Promise(resolve => {
      Papa.parse(csvText, {
        header: true,
        complete: results => {
          const match = results.data.find((row: any) => row.user_id === userId);
          if (match && match.recommendations) {
            try {
              const parsed = JSON.parse(match.recommendations);
              resolve(parsed);
            } catch {
              resolve([]);
            }
          } else {
            resolve([]);
          }
        },
      });
    });
  };

  const fetchRecommendations = async () => {
    const collab = await fetchCSVRecommendations('collaborative.csv', userId);
    const content = await fetchCSVRecommendations('content.csv', userId);
    const azure = ['999', '998', '997', '996', '995'];

    setRecommendations({
      collaborative: collab,
      content: content,
      azure: azure,
    });
  };

  return (
    <div className="App" style={{ padding: '2rem', fontFamily: 'sans-serif' }}>
      <h1>News Recommender</h1>
      <Selector
        userId={userId}
        setUserId={setUserId}
        onFetch={fetchRecommendations}
      />
      <RecommendationList
        title="Collaborative Filtering"
        items={recommendations.collaborative}
      />
      <RecommendationList
        title="Content-Based Filtering"
        items={recommendations.content}
      />
      <RecommendationList
        title="Azure ML Model"
        items={recommendations.azure}
      />
    </div>
  );
}

export default App;
